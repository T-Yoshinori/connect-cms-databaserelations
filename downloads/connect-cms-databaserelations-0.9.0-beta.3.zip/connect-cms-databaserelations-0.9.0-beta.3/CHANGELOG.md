# Changelog

## 0.9.0-beta.3 - 2026-09-29

- DB間の多対多リレーションに対応
- DBレコードとConnect-CMS Userの関連付けに対応
- DBレコードとConnect-CMS UserGroupの多対多関連付けに対応
- Entity Relationの値構造を汎用化し、target_max_count / target_unique をService層の制約として利用
- UserGroupはGroup本体を参照し、GroupUserの所属レコードは保存しない設計


## 0.9.0-beta.2 - 2026-09-27

- 関連情報カードの見出しを連携先DB名に変更
- 関連先DBの「一覧に表示する」項目を表ヘッダーとして使用
- 関連レコードを1件1行の一覧形式で表示
- タイトル項目から関連先詳細へ移動する既存導線を維持

## 0.9.0-beta.1 - 2026-09-26

初回ベータ公開。

- Connect-CMS汎用データベース間の双方向1対多リレーション
- 単数件側から複数レコード、複数件側から単一レコードの関連付け
- リレーション定義・編集・削除
- 関連付けの双方向編集
- Databases「リレーション連携」テンプレート
- 関連レコード詳細への相互移動
- DatabaseRelationsからDatabasesへの往復導線
- 新規インストール専用migration
